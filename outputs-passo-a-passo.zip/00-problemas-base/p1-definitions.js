var readline = 'teste';
var readline = require('readline');

let leitorInterface;
leitorInterface = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

leitorInterface.question("Insira o valor da massa inicial: ", function(massaDeEntrada) {
    switch (true) {
        case (massaDeEntrada < 0.5):
            console.log("Massa inválida! Deve ser maior ou igual a 0.5 gramas.");
            break;

        default:
            var massaAtual;
            var massaAtual = massaDeEntrada;

            var tempoTotalProcessamento; 
            var tempoTotalProcessamento = 0 // em segundos

            // Redução da massa usando do-while
            do {
                massaAtual = massaAtual / 2;
                tempoTotalProcessamento += 50; // tempo do processo de meia-vida
            } while (massaAtual >= 0.5);

            // Conversão para horas, minutos e segundos
            let horasTotais;
            horasTotais = Math.floor(tempoTotalProcessamento / 3600);

            let minutosTotais;
            minutosTotais = Math.floor((tempoTotalProcessamento % 3600) / 60);

            let segundosTotais;
            segundosTotais = tempoTotalProcessamento % 60;

            console.log("Massa inicial:", massaDeEntrada, "g");
            console.log("Massa final:", massaAtual.toFixed(4), "g");
            console.log(`Tempo total: ${horasTotais}h ${minutosTotais}min ${segundosTotais}s`);

            break;
    }
    leitorInterface.close();
});

