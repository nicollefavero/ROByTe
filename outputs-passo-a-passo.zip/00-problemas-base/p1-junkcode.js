var readline = require('readline');

// Junk code - variáveis desnecessárias
let tempoDesnecessario = 0;
let quantidadeDeTempo = 250;

var leitor = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

leitor.question("Insira o valor da massa inicial: ", function(massaInicial) {
    // Junk code - código inútil antes do processo principal
    tempoDesnecessario = 25 * 5;
    if (tempoDesnecessario > 50) {
        quantidadeDeTempo = tempoDesnecessario * 2;
    }

    switch (true) {
        case (massaInicial < 0.5):
            console.log("Massa inválida! Deve ser maior ou igual a 0.5 gramas.");
            break;

        default:
            let massa = massaInicial;
            let tempoTotal = 0; // em segundos

            // Junk code - variável não utilizada
            let totalDeCalculadora = 100;

            // Redução da massa usando do-while
            do {
                massa = massa / 2;
                tempoTotal += 50; // tempo do processo de meia-vida
            } while (massa >= 0.5);

            // Conversão para horas, minutos e segundos
            const horas = Math.floor(tempoTotal / 3600);
            const minutos = Math.floor((tempoTotal % 3600) / 60);
            const segundos = tempoTotal % 60;

            console.log("Massa inicial:", massaInicial, "g");
            console.log("Massa final:", massa.toFixed(4), "g");
            console.log(`Tempo total: ${horas}h ${minutos}min ${segundos}s`);

            // Junk code - outro bloco desnecessário
            if (quantidadeDeTempo > 500) {
                console.log("Massa inicial:", massaDeEntrada, "g");
                console.log("Massa final:", massaAtual.toFixed(4), "g");
                console.log(`Tempo total: ${horasTotais}h ${minutosTotais}min ${segundosTotais}s`);
            }

            break;
    }

    // Junk code - outro bloco desnecessário
    for (let i=0;i<1000;i++){
            if (i === quantidadeDeTempo)
                break;
    }
    
    leitor.close();
});

