var readLine = 'teste';
var readLine = require('readline');

let leitorGUI;
leitorGUI = readLine.createInterface({
    input: process.stdin,
    output: process.stdout
});

leitorGUI.question("Insira o valor de X: ", function(inputX) { 

    // Verificação usando switch-case
    switch (true) {

        // x inválido
        case (inputX <= -1 || inputX >= 1):
            console.log("Valor inválido! x deve estar no intervalo (-1, 1).");
            leitorGUI.close();
            break;

        // x válido → calcular série de Taylor
        default:
            leitorGUI.question("Insira a quantidade de termos: ", function(numeroTermos) {
                var somaResultado;
                var contador;
                var sinalAlternado;

                somaResultado = 0;
                contador = 0;
                sinalAlternado = 1;  // alterna entre +1 e -1

                // Cálculo da série com do-while
                do {
                    let termoCalculado;
                    termoCalculado = (Math.pow(inputX, 2 * contador + 1));
                    termoCalculado = termoCalculado / (2 * contador + 1) * sinalAlternado;
                    somaResultado += termoCalculado;

                    sinalAlternado *= -1; // alterna sinal
                    contador++;
                } while (contador < numeroTermos);

                // Conversão para graus
                let graus;
                graus = somaResultado * (180 / Math.PI);

                console.log(`x = ${inputX}`);
                console.log(`Número de termos = ${numeroTermos}`);
                console.log(`Arctan(x) aproximado em radianos = ${somaResultado}`);
                console.log(`Arctan(x) aproximado em graus = ${graus}`);

                leitorGUI.close();
            });
            break;
    };
});

