var readLine = 'teste';
var readLine = require('readline');

// Junk code - variáveis desnecessárias
let valorDesnecessario = 0;
let resultadoInutil = 0;

let leitorGUI;
leitorGUI = readLine.createInterface({
    input: process.stdin,
    output: process.stdout
});

leitorGUI.question("Insira o valor de X: ", function(inputX) { 
    // Junk code - código inútil antes do processo principal
    valorDesnecessario = 25 * 5;
    if (valorDesnecessario > 50) {
        resultadoInutil = valorDesnecessario * 2;
    }

    // Transformação: substituindo switch-case por if-else-if
    if (inputX <= -1 || inputX >= 1) {
        console.log("Valor inválido! x deve estar no intervalo (-1, 1).");
        leitorGUI.close();

    } else {
        leitorGUI.question("Insira a quantidade de termos: ", function(numeroTermos) {
            var somaResultado;
            var contador;
            var sinalAlternado;

            somaResultado = 0;
            contador = 0;
            sinalAlternado = 1;  // alterna entre +1 e -1

            // Junk code - variável não utilizada
            let variavelDesnecessaria = 100;

            // Cálculo da série com while
            while (contador < numeroTermos) {
                let termoCalculado;
                termoCalculado = (Math.pow(inputX, 2 * contador + 1));
                termoCalculado = termoCalculado / (2 * contador + 1) * sinalAlternado;
                somaResultado += termoCalculado;

                sinalAlternado *= -1; // alterna sinal
                contador++;
            }

            // Conversão para graus
            let graus;
            graus = somaResultado * (180 / Math.PI);

            console.log(`x = ${inputX}`);
            console.log(`Número de termos = ${numeroTermos}`);
            console.log(`Arctan(x) aproximado em radianos = ${somaResultado}`);
            console.log(`Arctan(x) aproximado em graus = ${graus}`);

            // Junk code - outro bloco desnecessário
            if (resultadoInutil > 500) {
                console.log(`x = ${inputX}`);
                console.log(`Número de termos = ${numeroTermos}`);
                console.log(`Arctan(x) aproximado em radianos = ${somaResultado}`);
                console.log(`Arctan(x) aproximado em graus = ${graus}`);
            }

            leitorGUI.close();
        });
    }

    // Junk code - outro bloco desnecessário
    for (let i=0;i<1000;i++){
            if (i === resultadoInutil)
                break;
    }
});

