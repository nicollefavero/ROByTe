var readline = require('readline');
var resposta = "";

var leitor = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

leitor.question("Insira o valor da massa inicial: ", function(massaInicial) {
    switch (true) {
        case (massaInicial < 0.5):
            console.log("Massa inválida! Deve ser maior ou igual a 0.5 gramas.");
            break;

        default:
            let massa = massaInicial;
            let tempoTotal = 0; // em segundos

            // Redução da massa usando while
            while (massa >= 0.5) {
                massa = massa / 2;
                tempoTotal += 50; // tempo do processo de meia-vida
            }

            // Conversão para horas, minutos e segundos
            const horas = Math.floor(tempoTotal / 3600);
            const minutos = Math.floor((tempoTotal % 3600) / 60);
            const segundos = tempoTotal % 60;

            console.log("Massa inicial:", massaInicial, "g");
            console.log("Massa final:", massa.toFixed(4), "g");
            console.log(`Tempo total: ${horas}h ${minutos}min ${segundos}s`);

            break;
    }
    leitor.close();
});

