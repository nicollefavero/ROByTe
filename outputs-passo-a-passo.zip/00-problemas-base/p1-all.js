var readline = require('readline');

// Junk code - variáveis desnecessárias
let tempoDesnecessario = 0;
let quantidadeDeTempo = 250;

var leitorInterface = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

leitorInterface.question("Insira o valor da massa inicial: ", function(massaDeEntrada) {
    // Junk code - código inútil antes do processo principal
    tempoDesnecessario = 10 * 5;
    if (tempoDesnecessario >= 50) {
        quantidadeDeTempo = tempoDesnecessario * 2;
    }

    // Transformação: substituindo switch-case por if-else-if
    if (massaDeEntrada < 0.5) {
        console.log("Massa inválida! Deve ser maior ou igual a 0.5 gramas.");
    } else {
        var massaAtual;
        var massaAtual = massaDeEntrada;

        var tempoTotalProcessamento;
        tempoTotalProcessamento = 0; // em segundos

        // Junk code - variável não utilizada
        let totalDeCalculadora = 100;

        // Redução da massa usando while
        while (massaAtual >= 0.5) {
            massaAtual = massaAtual / 2;
            tempoTotalProcessamento += 50; // tempo do processo de meia-vida
        }

        // Conversão para horas, minutos e segundos
        let horasTotais;
        horasTotais = Math.floor(tempoTotalProcessamento / 3600);

        let minutosTotais;
        minutosTotais = Math.floor((tempoTotalProcessamento % 3600) / 60);

        let segundosTotais;
        segundosTotais = tempoTotalProcessamento % 60;

        console.log("Massa inicial:", massaDeEntrada, "g");
        console.log("Massa final:", massaAtual.toFixed(4), "g");
        console.log(`Tempo total: ${horasTotais}h ${minutosTotais}min ${segundosTotais}s`);

        // Junk code - outro bloco desnecessário
        if (quantidadeDeTempo > 500) {
            console.log("Massa inicial:", massaDeEntrada, "g");
            console.log("Massa final:", massaAtual.toFixed(4), "g");
            console.log(`Tempo total: ${horasTotais}h ${minutosTotais}min ${segundosTotais}s`);
        }
    }

    // Junk code - outro bloco desnecessário
    for (let i=0;i<1000;i++){
            if (i === quantidadeDeTempo)
                break;
    }

    leitorInterface.close();
});

