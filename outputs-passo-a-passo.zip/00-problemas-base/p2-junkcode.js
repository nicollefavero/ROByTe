var readline = require('readline');

// Junk code - variáveis desnecessárias
let valorDesnecessario = 0;
let resultadoInutil = 0;

var leitor = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

leitor.question("Insira o valor de X: ", function(respostaX) { 
    // Junk code - código inútil antes do processo principal
    valorDesnecessario = 25 * 5;
    if (valorDesnecessario > 50) {
        resultadoInutil = valorDesnecessario * 2;
    }

    switch (true) {

        // x inválido
        case (respostaX <= -1 || respostaX >= 1):
            console.log("Valor inválido! x deve estar no intervalo (-1, 1).");
            leitor.close();
            break;

        // x válido → calcular série de Taylor
        default:
            leitor.question("Insira a quantidade de termos: ", function(termos) {
                let resultado = 0;
                let n = 0;
                let sinal = 1;  // alterna entre +1 e -1

                // Junk code - variável não utilizada
                let variavelDesnecessaria = 100;

                // Cálculo da série com do-while
                do {
                    let termo = (Math.pow(respostaX, 2 * n + 1) / (2 * n + 1)) * sinal;
                    resultado += termo;

                    sinal *= -1; // alterna sinal
                    n++;
                } while (n < termos);

                // Conversão para graus
                let graus = resultado * (180 / Math.PI);

                console.log(`x = ${respostaX}`);
                console.log(`Número de termos = ${termos}`);
                console.log(`Arctan(x) aproximado em radianos = ${resultado}`);
                console.log(`Arctan(x) aproximado em graus = ${graus}`);

                // Junk code - outro bloco desnecessário
                if (resultadoInutil > 500) {
                    console.log(`x = ${respostaX}`);
                    console.log(`Número de termos = ${termos}`);
                    console.log(`Arctan(x) aproximado em radianos = ${resultado}`);
                    console.log(`Arctan(x) aproximado em graus = ${graus}`);
                }
                
                leitor.close();
            });   
            break;      
    };

    // Junk code - outro bloco desnecessário
    for (let i=0;i<1000;i++){
            if (i === resultadoInutil)
                break;
    }
});

